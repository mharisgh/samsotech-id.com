$(document).ready(function () {
    function isTouchDevice() {
        return typeof window.ontouchstart !== 'undefined';
    }
    if (window.matchMedia("(max-width: 767px)").matches) {
        // The viewport is less than 768 pixels wide
        //alert("m");
        $('.d-menu').css('display', 'none');
        $('.grad_r_tran').css('width', 'auto');
        // $('.c_d').css('display', 'none');

    } else {
        // The viewport is at least 768 pixels wide
        //alert(" td");
        $('.m-menu').css('display', 'none');
        //$('.c_m').css('display', 'none');
    }

    //ADD BANNER IMAGE FOR EACH PAGE
    var page = window.location.href;
    // remove # from URL
    page = page.substring(0, (page.indexOf("#") == -1) ? page.length : page.indexOf("#"));
    // remove parameters from URL
    page = page.substring(0, (page.indexOf("?") == -1) ? page.length : page.indexOf("?"));
    // select file name
    page = page.substr(page.lastIndexOf("/") + 1);
    var pagewo = page.split('.').slice(0, -1).join('.');
    pageClass = pagewo + "-bg";
    //alert(page);

    $.get("includes/topbar.html", function (data) {
        $("#topbar").html(data);
    });
//    $.get("includes/header.html", function (data) {
//        $("#header").html(data);
//    });
    if ((pagewo == '') || (pagewo == 'index')) {
        $.get("includes/footer-home.html", function (data) {
            $("#footer").html(data);
        });
    } else {
        $.get("includes/footer.html", function (data) {
            $("#footer").html(data);
        });
    }
//    $.get("includes/recent-blogs.php", function (data) {
//        $("#recent-blogs").html(data);
//    });

    //alert("dfg");
    $.ajax({//create an ajax request to display.php
        type: "POST",
        url: "recent-blogs.php",
        dataType: "html", //expect html to be returned
        success: function (response) {
            $("#recent-blogs").html(response);
            //alert(response);
        }
    });


    $.get("includes/products.html", function (data) {
        $("#portfolio").html(data);
    });


    //if (pagewo != 'blog-details') {

    // $('.breadcrumbs').css('background-image', 'url("assets/img/' + pagewo + '-banner.jpg")');

    if ((pagewo == 'contactless-check-ins') || (pagewo == 'paperless-check-ins') || (pagewo == 'kiosk-check-ins') || (pagewo == 'mobile-check-ins') || (pagewo == 'vicas-hospitality') || (pagewo == 'vicas-spain') || (pagewo == 'passport-id-scanners') || (pagewo == 'everify') || (pagewo == 'anprconnect') || (pagewo == 'airlines') || (pagewo == 'evas') || (pagewo == 'epcr') || (pagewo == 'vicas-flight-manifest') || (pagewo == 'evac-tracker') || (pagewo == 'samsosmile')) {
        //alert(pagewo);
        $('.pros').css('background-image', 'url("assets/img/products/' + pagewo + '-banner.jpg")');
        $('.video-box').css('background-image', 'url("assets/img/products/' + pagewo + '-img.jpg")');
        $('#feature').prepend($('<img>', {src: 'assets/img/products/' + pagewo + '-feature.jpg'}))
    } else if (pagewo == 'blog-details') {
        //alert("blog-details");
        $('.breadcrumbs').addClass('blogs-title');
    } else if ((pagewo == 'hotels-resorts') || (pagewo == 'casinos-pubs-clubs') || (pagewo == 'security-organisations') || (pagewo == 'health-care') || (pagewo == 'airlines-immigration-and-border-control') || (pagewo == 'government-organisations')) {
        //alert("solutions");
        $('.solu').css('background-image', 'url("assets/img/solutions/' + pagewo + '-banner.jpg")');
        $('.video-box').css('background-image', 'url("assets/img/solutions/' + pagewo + '-img.jpg")');
        $('#feature').prepend($('<img>', {src: 'assets/img/solutions/' + pagewo + '-feature.jpg'}))
    } else if ((pagewo == 'index') || (pagewo == '')) {
        $('.breadcrumbs').css('background-image', 'url("assets/img/' + pagewo + '-banner.jpg")');
        $('.video-box').css('background-image', 'url("assets/img/about-img.jpg")');
    } else if ((pagewo == 'pivacy-policy') || (pagewo == '')) {
        $('.breadcrumbs').css('background-image', 'url("assets/img/' + pagewo + '-banner.jpg")');
    } else {
        $('.breadcrumbs').css('background-image', 'url("assets/img/' + pagewo + '-banner.jpg")');
        $('.video-box').css('background-image', 'url("assets/img/' + pagewo + '-img.jpg")');
    }









    // Get current page URL
    var url = window.location.href;

    // remove # from URL
    url = url.substring(0, (url.indexOf("#") == -1) ? url.length : url.indexOf("#"));

    // remove parameters from URL
    url = url.substring(0, (url.indexOf("?") == -1) ? url.length : url.indexOf("?"));

    // select file name
    url = url.substr(url.lastIndexOf("/") + 1);
    // If file name not avilable
    if (url == '') {
        url = 'index.html';
    }
    // Loop all menu items
    $('.navbar1 li').each(function () {
        // select href
        var href = $(this).find('a').attr('href');
        //
        // Check filename
        if (url == href) {

            var parentClass = $(this).parent('ul').children('li').attr('class');
            if (parentClass == 'submenu') {
                // Add class
                $(this).children('a').addClass('active');
                $(this).parent('ul').parent().children('a').addClass('active');
            } else if (parentClass == 'first') {
                $(this).children('a').addClass('active');
            } else {
                // Add class
                $(this).addClass('active');
            }

        }
    });

    document.getElementById("primary_form").addEventListener("submit", function (evt)
    {

        var response = grecaptcha.getResponse();
        if (response.length == 0)
        {
            //reCaptcha not verified
            alert("reCAPTCHA Error! Please check and try again.");
            evt.preventDefault();
            return false;
        }
        //captcha verified
        //do the rest of your validations here

    });
});

